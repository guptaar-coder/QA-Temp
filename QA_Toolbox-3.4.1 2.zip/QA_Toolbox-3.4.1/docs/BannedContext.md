# Banned Word Context<br>

## Pricing
Terms that are restricted if they are referring to price. For example: “We’ll meet any price you find from our competitors” - this is not compliant because it involves pricing. “Meet our staff!” – this is compliant because it doesn’t refer to pricing.<br>
•	meet<br>
•	Beat<br>
•	Match<br>
•	Free<br>
•	Deal<br>
•	Save<br>
•	Cost<br>
•	Surpass<br>
•	Crush<br>

## Claims
Terms that are restricted if they have no proof to back a claim. For example: “We are the biggest Ford dealer in Oregon!” – this claim needs to be supported by reasonable sources, otherwise it is not compliant. <br>
•	Biggest<br>
•	Newest<br>
•	Best<br>
•	Largest<br>
•	First<br>
•	Safest<br>
•	Only<br>
